#ifndef __BISHOP_H__
#define __BISHOP_H__

#include "piece.h"
#include <vector>
using namespace std;

class Bishop: public Piece {
    char symbol = 'b';
    public:
        Bishop(pair<int, int> pos, string colour);
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        virtual Piece* clone() const override;
};


#endif
