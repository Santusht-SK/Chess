#include "piece.h"

using namespace std;

Piece::Piece(pair<int, int> pos, string colour): pos{pos}, colour{colour} {}

string Piece::getColour() {
    return colour;
}

pair<int,int> Piece::getPos() const {
    return pos;
}

void Piece::move(pair<int, int> newPos) {
    pos.first = newPos.first;
    pos.second = newPos.second;
}
