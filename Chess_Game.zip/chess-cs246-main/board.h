#ifndef __BOARD_H__
#define __BOARD_H__

using namespace std;
#include "piece.h"
#include "rook.h"
#include "empty.h"
#include "queen.h"
#include "king.h"
#include "knight.h"
#include "pawn.h"
#include "bishop.h"

class Board {
    
    vector<vector<Piece*>> grid;

    public:
        Board();
        bool isValid();
        bool isCheckmate(string col);
        bool isDraw();
        bool isStalemate(string col);
        bool isCheck(string col);
        void turnOffMovedTwo(string col);
        bool isLegalMove(Move m, string col, bool needsCheck, bool isHuman);
        void makeMove(Move move, char pawnPromote);
        void setPos(char c, pair<int, int> pos);
        char getChar(int row, int col);
        vector<Move> getLegalMoves(string col);
        bool capturesPiece(Move move, string col);

        ~Board();
        Board(const Board &other);
        Board &operator=(const Board &other);
};

#endif
