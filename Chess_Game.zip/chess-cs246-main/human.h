#ifndef __HUMAN_H__
#define __HUMAN_H__
#define pii pair<int, int>

#include "player.h"
#include <iostream>




class Human: public Player {
    
    public:
        Human(string col);
        virtual Move getMove(Board &b) override;
        virtual bool isHuman() override;

};

#endif
