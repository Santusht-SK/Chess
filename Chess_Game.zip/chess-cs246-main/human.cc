#include "human.h"


Human::Human(string col): Player{col} {}

pii convertPs(string pos) {
    int r = pos[0]-97;
    return pii{8 - (pos[1] - '0'), r}; 
} 

Move Human::getMove(Board &b) {
    cout << "Enter your move:" << endl;
    cout << "the format is: (starpos) (endpos)" << endl;
    string start, end;
    
    while(!cin.eof()) {
        cin >> start >> end;
        if(start.length() != 2 || end.length() != 2 || start[0] < 'a' 
        || end[0] < 'a' || start[1] > '8' || end[1] > '8') {
            cout << "Invalid start or end position" << endl;
            continue;
        }
        break;
    }
    return Move{convertPs(start), convertPs(end)};
}

bool Human::isHuman() {
    return true;
}
