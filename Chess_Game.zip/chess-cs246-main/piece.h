#ifndef __PIECE_H__
#define __PIECE_H__

#include <iostream>
#include <vector>
#include <utility>

using namespace std;

struct Move {
    pair<int, int> start;
    pair<int, int> end;

    Move(pair<int, int> start, int end1, int end2): start{start}, end{pair<int, int>{end1, end2}} {}
    Move(pair<int, int> start, pair<int, int> end): start{start}, end{end} {}
};

class Piece {
    pair<int, int> pos;
    string colour;
    public:
        Piece(pair<int, int> pos, string colour);
        void move(pair<int, int> newPos);
        pair<int, int>  getPos() const; // return type shouldn't be string 
        virtual vector<Move> getMoves() = 0;
        string getColour();
        void setPos(pair<int, int> newPos);
        virtual char getChar() = 0;
        virtual Piece* clone() const = 0;
        virtual ~Piece() = default;
};



#endif
