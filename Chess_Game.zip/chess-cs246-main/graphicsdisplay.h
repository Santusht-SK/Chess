#ifndef __GRAPHICSDISPLAY_H__
#define __GRAPHICSDISPLAY_H__

#include "window.h"
#include "board.h"
#include <string>


class GraphicsDisplay {
    Xwindow xw;
    Board b;
    int wSize;

    public:
        GraphicsDisplay();

        void notify(Board &bo);

        ~GraphicsDisplay();

};
#endif
