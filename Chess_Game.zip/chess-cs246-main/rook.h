#ifndef __ROOK_H__
#define __ROOK_H__

#include "piece.h"
using namespace std;

class Rook: public Piece {
    char symbol = 'r';
    bool moved = false;
    public:
        Rook(pair<int, int> pos, string colour);
        void setMoved();
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        bool isMoved();
        virtual Piece* clone() const override;
};


#endif
