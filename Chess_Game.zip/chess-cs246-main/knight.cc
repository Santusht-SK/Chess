#include "knight.h"

using namespace std;

Knight::Knight(pair<int, int> pos, string colour): Piece{pos, colour} {}

Knight::~Knight() {}

vector<Move> Knight::getMoves() {
    vector<Move> moves;
    int row = getPos().first;
    int col = getPos().second;

    // double chekc if these are all the knight combinations
    int rowMoves[] = {-1, 1, -1, 1, -2, 2, -2, 2};
    int colMoves[] = {-2, 2, 2, -2, -1, 1, 1, -1};
    for (int i = 0; i <= 7; i++){
 
            if (colMoves[i] + col >= 0 && colMoves[i] + col  <= 7 && rowMoves[i] + row  >= 0 && rowMoves[i] + row  <= 7) {
                moves.emplace_back(Move{getPos(),rowMoves[i] + row , colMoves[i] + col});
            }
    }
    return moves;
}

char Knight::getChar() {
    if(this->getColour() == "White") {
        return toupper(symbol);
    }
    return symbol;
} 

Piece* Knight::clone() const {
    return new Knight(*this);
}
