#include "king.h"

using namespace std;

King::King(pair<int, int> pos, string colour): Piece{pos, colour} {}


vector<Move> King::getMoves() {
    vector<Move> moves;
    pair<int, int> start = getPos();
    int row = getPos().first;
    int col = getPos().second;

    for (int i = row - 1; i <= row + 1; i++){
        for(int j = col - 1; j <= col + 1; j++) {
            if (j >= 0 && j <= 7 && i >= 0 && i <= 7 && (j != col || i != row)) {
                moves.emplace_back(Move{start, {i, j}});
            }
        }
    }
    if (isMoved() == false && (col == 3 || col == 4)) {
        moves.emplace_back(Move{start, {row, col + 2}});
        moves.emplace_back(Move{start, {row, col - 2}});

    }

    return moves;
}



char King::getChar() {
    if(this->getColour() == "White") {
        return toupper(symbol);
    }
    return symbol;
} 


bool King::isMoved() {
    // if they move back to their original spot, moved will still be true
    if (this->moved == true) {
        return true;
    }

    // check if kings havent moved and are in their original spot
    else if (this->moved == false && ((this->getColour() == "White" && this->getPos() == pair<int, int>(7,4)) || (this->getColour() == "Black" && this->getPos() == pair<int, int>(0,4)))) {
        return false;
    }

    // set it so the king now has its moved to true and that won't change
    this->moved = true;
    return true;
}

Piece* King::clone() const {
    return new King(*this);
}

void King::setMoved() {
    moved = true;
}


