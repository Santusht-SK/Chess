#ifndef __KNIGHT_H__
#define __KNIGHT_H__

#include "piece.h"
using namespace std;

class Knight: public Piece {
    char symbol = 'n';
    public:
        Knight(pair<int, int> pos, string colour);
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        virtual Piece* clone() const override;
        ~Knight();
};


#endif
