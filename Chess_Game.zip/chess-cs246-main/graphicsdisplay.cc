#include "graphicsdisplay.h"

GraphicsDisplay::GraphicsDisplay(): xw{820, 820}, b{Board{}}, wSize{800} {

    xw.drawLine(20, 0, 20, wSize);

    // Draw border lines
    for(int i = 0; i < 8; i++) {
        xw.drawLine(20 + (wSize/8) * i, 0, 20 + (wSize/8) * i, wSize);
    }
    for(int i = 0; i < 9; i++) {
        xw.drawLine(20, (wSize/8) * i, wSize + 20, (wSize/8) * i);
    }

    // Draw squares
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if((i + j) % 2 == 0) {
                xw.fillRectangle((wSize/8) * j + 21,(wSize/8) * i + 1, 
                wSize/8 -1, wSize/8 - 1, 0);
            }
            else {
                xw.fillRectangle((wSize/8) * j + 21,(wSize/8) * i + 1, 
                wSize/8 -1, wSize/8 - 1, 1);
            }
        }
    }

    xw.setCol("Black");
    // Draw numbers on side
    for(int i = 0; i < 9; i++) {
        xw.drawString(0, (wSize+20) - ((wSize/8) * (i) - 40), to_string(i));
    }

    //draw letters at bottom
    for(char c = 'a'; c < 'i'; c++) {
        xw.drawString((wSize/8) * (c - 97) + 70, 820, string{c});
    }
    
    xw.setCol("Red");
    //draw default board
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if(b.getChar(i ,j) == '_' || b.getChar(i ,j) == ' ') {
                continue;
            }
            if(islower(b.getChar(i,j))) {
                xw.setCol("Black");
                string s{b.getChar(i,j)};
                xw.fillRectangle(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) -15, 15, 30, 3);
                xw.drawString(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) + 5, s);
            }
            else {
                xw.setCol("White");
                string s{b.getChar(i,j)};
                xw.fillRectangle(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) -20, 20, 30, 2);
                xw.drawString(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) + 5, s);
            }
        }
    }


    //xw.fillRectangle()*/

}

void GraphicsDisplay::notify(Board &bo) {
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if(bo.getChar(i, j) == b.getChar(i, j)) {

                // only redraw updated squares
                continue;
            }
            if((i + j) % 2 == 0) {

                // fill white on even tiles

                xw.fillRectangle((wSize/8) * j + 21,(wSize/8) * i + 1, 
                wSize/8 -1, wSize/8 - 1, 0);
            }
            else {
                xw.fillRectangle((wSize/8) * j + 21,(wSize/8) * i + 1, 
                wSize/8 -1, wSize/8 - 1, 1);
            }
            string s{bo.getChar(i,j)};
            
            // dont draw a character if the square is empty
            if(s == "_" || s == " ") continue;


            if(islower(bo.getChar(i,j))) {

                xw.setCol("Black");
                xw.fillRectangle(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) -15, 15, 30, 3);

                xw.drawString(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) + 5, s);

            }
            else {
                xw.setCol("White");
                xw.fillRectangle(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) -20, 20, 30, 2);
                xw.drawString(((wSize/8) * j) + (wSize/16) + 15,
                ((wSize/8) * (i)) + (wSize/16) + 5, s);
                xw.setCol("Black");
            }
        }
    }
    this->b = bo;
}

GraphicsDisplay::~GraphicsDisplay() {}
