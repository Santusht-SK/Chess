#ifndef __EMPTY_H__
#define __EMPTY_H__

#include "piece.h"
using namespace std;

class Empty: public Piece {
    char symbol = '_';
    public:
        Empty(pair<int,int> pos);
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        virtual Piece* clone() const override;
};


#endif
