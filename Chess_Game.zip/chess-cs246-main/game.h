#ifndef __GAME_H__
#define __GAME_H__

#include "board.h"
#include "textdisplay.h"
#include "graphicsdisplay.h"
#include <string>
#include "player.h"
#include "human.h"
#include "computer.h"
#include <memory>

using namespace std;

class Game {
    Board b;
    TextDisplay *td;
    GraphicsDisplay *gd;
    float whiteScore = 0;
    float blackScore = 0;
    string turn;
    std::unique_ptr<Player> pWhite;
    std::unique_ptr<Player> pBlack;

    public:
        Game();
        void remove(pair<int,int> pos);
        void addPiece(pair<int,int> pos, Piece &p);
        void setTurn(string col);
        void printResults();
        void updateBoard();
        bool makeMove(pair<int, int> p1, pair<int, int> p2, string colour);
        void runGame();
        void clearBoard();
        
        ~Game();

    
};

#endif
