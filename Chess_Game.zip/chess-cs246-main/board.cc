#include "board.h"
#include <utility>
#include <iostream>
#define pii std::pair<int, int>

const int GRID_SIZE = 8;

Board::Board()
{
    grid.resize(8, vector<Piece *>(8, nullptr));

    grid[0][0] = new Rook{pair<int, int>{0, 0}, "Black"};
    grid[0][7] = new Rook{pair<int, int>{0, 7}, "Black"};
    grid[7][0] = new Rook{pair<int, int>{7, 0}, "White"};
    grid[7][7] = new Rook{pair<int, int>{7, 7}, "White"};

    grid[0][1] = new Knight{pair<int, int>{0, 1}, "Black"};
    grid[0][6] = new Knight{pair<int, int>{0, 6}, "Black"};
    grid[7][1] = new Knight{pair<int, int>{7, 1}, "White"};
    grid[7][6] = new Knight{pair<int, int>{7, 6}, "White"};

    grid[0][2] = new Bishop{pair<int, int>{0, 2}, "Black"};
    grid[0][5] = new Bishop{pair<int, int>{0, 5}, "Black"};
    grid[7][2] = new Bishop{pair<int, int>{7, 2}, "White"};
    grid[7][5] = new Bishop{pair<int, int>{7, 5}, "White"};

    grid[0][3] = new Queen{pair<int, int>{0, 3}, "Black"};
    grid[7][3] = new Queen{pair<int, int>{7, 3}, "White"};

    grid[0][4] = new King{pair<int, int>{0, 4}, "Black"};
    grid[7][4] = new King{pair<int, int>{7, 4}, "White"};

    for (int i = 2; i <= 5; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            grid[i][j] = new Empty{pair<int, int>{i, j}};
        }
    }

    for (int i = 0; i < 8; i++)
    {
        grid[1][i] = new Pawn{pair<int, int>{1, i}, "Black"};
    }
    for (int i = 0; i < 8; i++)
    {
        grid[6][i] = new Pawn{pair<int, int>{6, i}, "White"};
    }
}

void Board::turnOffMovedTwo(string col)
{
    for (size_t i = 0; i < GRID_SIZE; i++)
    {
        for (size_t j = 0; j < GRID_SIZE; j++)
        {
            if (grid[i][j]->getChar() == 'p' || grid[i][j]->getChar() == 'P')
            {

                if (dynamic_cast<Pawn *>(grid[i][j])->getColour() != col && dynamic_cast<Pawn *>(grid[i][j])->isMovedTwo())
                {
                    //cout << "Pawn" << i << j << grid[i][j]->getColour() << "Moved two turned off" << endl;
                    dynamic_cast<Pawn *>(grid[i][j])->setMovedTwo(false);
                }
            }
        }
    }
}
bool Board::isCheckmate(string col)
{
    if (isCheck(col))
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            for (int j = 0; j < GRID_SIZE; j++)
            {
                if (grid[i][j]->getColour() == col)
                {
                    vector<Move> moves = grid[i][j]->getMoves();
                    for (size_t k = 0; k < moves.size(); k++)
                    {
                        Move curMove = moves[k];
                        if (isLegalMove(curMove, col, true, false))
                        {
                            //cout << "found a move to stop checkmate" << endl;
                            //cout << curMove.start.first << curMove.start.second << " " << curMove.end.first << curMove.end.second << endl;
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }
    // if not in check you won't be in checkmate
    return false;
}

// enhancements
bool Board::isDraw() {
        int countWKnights = 0;
        int countBKnights = 0;
        int countWBishops = 0;
        int wBishopLocation = 0;
        int wBishopLocationTwo = 0;
        int countBBishops = 0;
        int bBishopLocation = 0;
        int bBishopLocationTwo = 0;
        int otherChars = 0;

         for (int i = 0; i < GRID_SIZE; i++) {

         
            for (int j = 0; j < GRID_SIZE; j++)
            { 
                // check for draw conditions (just 2 kings or 2 king 1 knight or 2 king 1 bishop or 2 kings and 1 bishop each side on same colour)
                if(grid[i][j]->getChar() == 'N') {
                    countWKnights += 1;
            }
                else if (grid[i][j]->getChar() == 'n') {
                    countBKnights += 1;
                }

                else if (grid[i][j]->getChar() == 'B') {
                    countWBishops += 1;
                    wBishopLocation = i % 2;
                    wBishopLocationTwo = j % 2;
                }

                else if (grid[i][j]->getChar() == 'b') {
                    countBBishops += 1;
                    bBishopLocation = i % 2;
                    bBishopLocationTwo = j % 2;
                }

                else if(grid[i][j]->getChar() != ' ' && grid[i][j]->getChar() != '_' && grid[i][j]->getChar() != 'k' && grid[i][j]->getChar() != 'K') {
                    otherChars += 1;
                    break;
                }
            }
         }
         if(otherChars == 0 && ((countWKnights == 0 && countBKnights == 0 && countWBishops == 0 && countBBishops == 0) ||
             (countWKnights == 1 && countBKnights == 0 && countWBishops == 0 && countBBishops == 0) || 
                (countWKnights == 0 && countBKnights == 1 && countWBishops == 0 && countBBishops == 0) ||
                    (countWKnights == 0 && countBKnights == 0 && countWBishops == 1 && countBBishops == 0) ||
                        (countWKnights == 0 && countBKnights == 0 && countWBishops == 0 && countBBishops == 1) || 
                            (countWKnights == 0 && countBKnights == 0 && countWBishops == 1 && countBBishops == 1 && ((wBishopLocation + wBishopLocationTwo) % 2 == (bBishopLocation + bBishopLocationTwo) % 2)))) {
                                return true;
                        }
        return false;
}

bool Board::isStalemate(string col)
{   if (isDraw()) {
        return true;
}
    if (!isCheck(col))
    {   
       
        for (int i = 0; i < GRID_SIZE; i++)
        {
            for (int j = 0; j < GRID_SIZE; j++)
            { 
                if (grid[i][j]->getColour() == col)
                {
                    vector<Move> moves = grid[i][j]->getMoves();
                    for (size_t k = 0; k < moves.size(); k++)
                    {
                        Move curMove = moves[k];
                        if (isLegalMove(curMove, col, true, false))
                        {

                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }
    // if not in check you won't be in checkmate
    return false;
}

bool Board::isValid()
{
    int wkings = 0;
    int bkings = 0;
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            if (grid[i][j]->getChar() == 'k')
            {
                bkings += 1;
            }

            
            else if (grid[i][j]->getChar() == 'K')
            {
                wkings += 1;
            }
            if ((i == 0 || i == 7) && toupper(grid[i][j]->getChar()) == 'P')
            {
                return false;
            }
        }
    }
    if (wkings != 1)
        return false;
    if (bkings != 1)
        return false;
    if (isCheck("White"))
        return false;
    if (isCheck("Black"))
        return false;
    if (isCheckmate("Black") || isCheckmate("White"))
        return false;
    return true;
}

// gotta fix the infinite recursion
bool Board::isCheck(string colour)
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            if (grid[i][j]->getColour() == colour)
            {
                continue;
            }
            vector<Move> moves = grid[i][j]->getMoves();
            for (auto move : moves)
            {
                if (colour == "White")
                {
                    if (grid[move.end.first][move.end.second]->getChar() == 'K' && isLegalMove(move, "Black", false, false))
                    {
                       
                        return true;
                    }
                }
                else
                {
                    if (grid[move.end.first][move.end.second]->getChar() == 'k' && isLegalMove(move, "White", false, false))
                    {
                       
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

bool Board::isLegalMove(Move move, string colour, bool needsCheck, bool isHuman)
{

    // assuming we keep the Move struct the same
    int startPosRow = move.start.first;
    int startPosCol = move.start.second;

    int endPosRow = move.end.first;
    int endPosCol = move.end.second;
    string currentPieceColour = grid[startPosRow][startPosCol]->getColour();

    if (currentPieceColour != colour)
    { 

        return false;
    }

    if (startPosRow < 0 || startPosRow > 7 || startPosCol < 0 || startPosCol > 7 || endPosRow < 0 || endPosRow > 7 || endPosCol < 0 || endPosCol > 7)
    {
        return false;
    }

    // everything below checks if our move is in getMoves()

    vector<Move> possibleBlankMoves = grid[startPosRow][startPosCol]->getMoves();

    bool foundMove = false;
    for (size_t i = 0; i < possibleBlankMoves.size(); i++)
    {
        
        if (possibleBlankMoves[i].start == move.start && possibleBlankMoves[i].end == move.end)
        {
            foundMove = true;
            break;
        }
    }

    if (foundMove == false)
    {
        if (needsCheck && isHuman)
            cout << endl << "That piece cannot move there! ";
        return false;
    }

    // check if the ending position doesn't have our piece already there (if opposite colour we can capture)
    // debug for castling **********
    if (grid[endPosRow][endPosCol]->getColour() == currentPieceColour)
    {
        if (needsCheck && isHuman)
            cout << endl << "Your piece is already there! ";
        return false;
    }

    // Castling
    // move right
    bool canCastle = false;
    if ((endPosCol - startPosCol) == 2 && (grid[startPosRow][startPosCol]->getChar() == 'k' || grid[startPosRow][startPosCol]->getChar() == 'K'))
    {
        if (!dynamic_cast<King *>(grid[startPosRow][startPosCol])->isMoved() && endPosCol + 1 == 7 && (!isCheck(grid[startPosRow][startPosCol]->getColour())) && ((grid[startPosRow][startPosCol + 1]->getChar() == ' ') || (grid[startPosRow][startPosCol + 1]->getChar() == '_')) && ((grid[startPosRow][startPosCol + 2]->getChar() == ' ') || (grid[startPosRow][startPosCol + 2]->getChar() == '_')) && (grid[startPosRow][7]->getChar() == 'r' || grid[startPosRow][7]->getChar() == 'R'))
        {
            if (!dynamic_cast<Rook *>(grid[startPosRow][7])->isMoved())
            {
                // check if space in between are underattack
                Board copyOfBoard = *this;
                copyOfBoard.makeMove((Move(std::make_pair(startPosRow, startPosCol), startPosRow, startPosCol + 1)), '\0');

                Board copyOfBoardTwo = *this;
                copyOfBoard.makeMove((Move(std::make_pair(startPosRow, startPosCol), startPosRow, startPosCol + 2)), '\0');

                if ((!copyOfBoard.isCheck(colour)) && (!copyOfBoardTwo.isCheck(colour)))
                {
                    canCastle = true;
                }
                else
                {
                    if (needsCheck && isHuman)
                        cout << endl << "The King's Path is under attack!, ";
                }
            }
        }
        else if (!canCastle)
        {

            if (needsCheck && isHuman)
                cout << endl <<"cant castle, ";
            return false;
        }
    }

    // move left
    else if ((startPosCol - endPosCol) == 2 && (grid[startPosRow][startPosCol]->getChar() == 'k' || grid[startPosRow][startPosCol]->getChar() == 'K'))
    {
        if (!dynamic_cast<King *>(grid[startPosRow][startPosCol])->isMoved() && (!isCheck(grid[startPosRow][startPosCol]->getColour())) && endPosCol - 2 == 0 && ((grid[startPosRow][startPosCol - 1]->getChar() == ' ') || (grid[startPosRow][startPosCol - 1]->getChar() == '_')) && ((grid[startPosRow][startPosCol - 2]->getChar() == ' ') || (grid[startPosRow][startPosCol - 2]->getChar() == '_')) && ((grid[startPosRow][startPosCol - 3]->getChar() == ' ') || (grid[startPosRow][startPosCol - 3]->getChar() == '_')) && (grid[startPosRow][0]->getChar() == 'r' || grid[startPosRow][0]->getChar() == 'R'))
        {
            if (!dynamic_cast<Rook *>(grid[startPosRow][0])->isMoved())
            {

                Board copyOfBoard = *this;
                copyOfBoard.makeMove(Move(std::make_pair(startPosRow, startPosCol), startPosRow, startPosCol - 1), '\0');

                Board copyOfBoardTwo = *this;
                copyOfBoard.makeMove(Move(std::make_pair(startPosRow, startPosCol), startPosRow, startPosCol - 2), '\0');

                if ((!copyOfBoard.isCheck(colour)) && (!copyOfBoardTwo.isCheck(colour)))
                {
                    canCastle = true;
    
                }
                else
                {
                    if (needsCheck && isHuman)
                        cout << endl << "The King's Path is under attack!, ";
                }
            }
        }
        else if (!canCastle)
        {
            if (needsCheck && isHuman)
                cout << endl << "cant castle, ";
            return false;
        }
    }
    // now let's check if a piece is in the way

    // for diagonal movement
    else if (abs(startPosCol - endPosCol) == abs(startPosRow - endPosRow))
    {
        int iterateXSpaces;
        int iterateYSpaces;

        if (endPosCol > startPosCol)
        {
            iterateYSpaces = 1;
        }

        else
        {
            iterateYSpaces = -1;
        }

        if (endPosRow > startPosRow)
        {
            iterateXSpaces = 1;
        }

        else
        {
            iterateXSpaces = -1;
        }

        // capturing with a pawn
        if (abs(startPosCol - endPosCol) == 1 && (grid[startPosRow][startPosCol]->getChar() == 'p' || grid[startPosRow][startPosCol]->getChar() == 'P'))
        {
            if (grid[endPosRow][endPosCol]->getChar() != ' ' && grid[endPosRow][endPosCol]->getChar() != '_')
            {
                if (grid[endPosRow][endPosCol]->getColour() != grid[startPosRow][startPosCol]->getColour())
                {
                }
            }

            // EnPassant
            else
            {
                int enPassantRow;
                int enPassantCol = endPosCol;
                bool canEnPassant = false;
                if (currentPieceColour == "White")
                {
                    enPassantRow = endPosRow + 1;
                    if (grid[enPassantRow][enPassantCol]->getChar() == 'p' && dynamic_cast<Pawn *>(grid[enPassantRow][enPassantCol])->isMovedTwo())
                    {
                        canEnPassant = true;
                    }
                }
                else
                {
                    enPassantRow = endPosRow - 1;
                    if (grid[enPassantRow][enPassantCol]->getChar() == 'P' && dynamic_cast<Pawn *>(grid[enPassantRow][enPassantCol])->isMovedTwo())
                    {
                        canEnPassant = true;

                    }
                }
                if (!canEnPassant)
                {
                    if (needsCheck  && isHuman)
                        cout << endl << "Can't EnPassant, " << endl;
                    return false;
                }
            }
        }
        // diagonal movements with other pieces
        for (int i = startPosRow + iterateXSpaces, j = startPosCol + iterateYSpaces; i != endPosRow; i += iterateXSpaces, j += iterateYSpaces)
        {
            if (grid[i][j]->getChar() != '_' && grid[i][j]->getChar() != ' ')
            {
                if (needsCheck && isHuman)
                    cout << endl << "a piece is in the way of diagonal movement, ";
                return false;
            }
        }
    }

    // for horizontal movement
    else if (startPosRow == endPosRow)

    {

        // for backwards movement
        if (endPosCol < startPosCol)
        {
            for (int i = startPosCol - 1; i != endPosCol; i--)
            {
                if (grid[startPosRow][i]->getChar() != '_' && grid[startPosRow][i]->getChar() != ' ')
                {
                    if (needsCheck && isHuman)
                        cout << endl << "a piece is in the way of Horizontal movement, ";
                    return false;
                }
            }
        }
        // for forward movement
        if (endPosCol > startPosCol)
        {
            for (int i = startPosCol + 1; i != endPosCol; i++)
            {
                if (grid[startPosRow][i]->getChar() != '_' && grid[startPosRow][i]->getChar() != ' ')
                {
                    return false;
                }
            }
        }
    }

    // for vertical movement
    else if (startPosCol == endPosCol)
    {
        
        // for backwards movement
        if (endPosRow < startPosRow)
        {
            if (grid[startPosRow][startPosCol]->getChar() == 'P')
            {
                if (grid[endPosRow][endPosCol]->getChar() != ' ' && grid[endPosRow][endPosCol]->getChar() != '_')
                {
                    if (needsCheck && isHuman) cout << endl << "White Pawn is blocked, ";
                    return false;
                }
            }
            for (int i = startPosRow - 1; i > endPosRow; i--)
            {
                if (grid[i][startPosCol]->getChar() != '_' && grid[i][startPosCol]->getChar() != ' ')
                {
                    if (needsCheck && isHuman)
                        cout << endl << "A Piece is in the Way of Vertical Movement, ";
                    return false;
                }
            }
        }
        // for forward movement
        if (endPosRow > startPosRow)
        {
            
            if (grid[startPosRow][startPosCol]->getChar() == 'p')
            {
                if (grid[endPosRow][endPosCol]->getChar() != ' ' && grid[endPosRow][endPosCol]->getChar() != '_')
                {
                    if (needsCheck && isHuman)
                        cout << endl << "Black Pawn is blocked, ";
                    return false;
                }
            }
            for (int i = startPosRow + 1; i < endPosRow; i++)
            {
                if (grid[i][startPosCol]->getChar() != '_' && grid[i][startPosCol]->getChar() != ' ')
                {

                    if (needsCheck && isHuman)

                    cout << endl << "A Piece is in the Way of Vertical Movement, ";

                    return false;
                }
            }
        }
    }

    // now let's check if we are in check

    if (needsCheck)
    {
        Board copyOfBoard = *this;
        copyOfBoard.makeMove(Move(std::make_pair(startPosRow, startPosCol), endPosRow, endPosCol), '\0');

        if ((colour == "White" && copyOfBoard.isCheck("White")) || (colour == "Black" && copyOfBoard.isCheck("Black")))
        {   
            if (isHuman) cout << endl << "can't make that move you are in check, ";
            
            return false;
        }

        return true;
    }
    return true;
}
// add if its a pawn, and it moved twice then set its isMoved to true

char Board::getChar(int i, int j)
{

    return grid[i][j]->getChar();
    return 'c';
}

void Board::setPos(char c, pair<int, int> pos)
{
    int r = pos.first;
    int co = pos.second;
    delete grid[r][co];

    if (c == 'k')
        grid[r][co] = new King{pos, "Black"};
    if (c == 'r')
        grid[r][co] = new Rook{pos, "Black"};
    if (c == 'p')
        grid[r][co] = new Pawn{pos, "Black"};
    if (c == 'q')
        grid[r][co] = new Queen{pos, "Black"};
    if (c == 'n')
        grid[r][co] = new Knight{pos, "Black"};
    if (c == 'b')
        grid[r][co] = new Bishop{pos, "Black"};

    if (c == 'K')
        grid[r][co] = new King{pos, "White"};
    if (c == 'R')
        grid[r][co] = new Rook{pos, "White"};
    if (c == 'P')
        grid[r][co] = new Pawn{pos, "White"};
    if (c == 'Q')
        grid[r][co] = new Queen{pos, "White"};
    if (c == 'N')
        grid[r][co] = new Knight{pos, "White"};
    if (c == 'B')
        grid[r][co] = new Bishop{pos, "White"};
    if (c == 'e')
        grid[r][co] = new Empty{pos};
}

void Board::makeMove(Move move, char pawnPromote)
{
    using std::swap;
    int startPosRow = move.start.first;
    int startPosCol = move.start.second;
    int endPosRow = move.end.first;
    int endPosCol = move.end.second;
    string currentColour = grid[startPosRow][startPosCol]->getColour();

    // make the move for enPassant
    if (abs(startPosCol - endPosCol) == 1 && (grid[startPosRow][startPosCol]->getChar() == 'p' || grid[startPosRow][startPosCol]->getChar() == 'P') && (grid[endPosRow][endPosCol]->getChar() == ' ' || grid[endPosRow][endPosCol]->getChar() == '_'))
    {
        int enPassantRow;
        int enPassantCol = endPosCol;
        if (grid[startPosRow][startPosCol]->getChar() == 'P')
        {
            enPassantRow = endPosRow + 1;
            if (grid[enPassantRow][enPassantCol]->getChar() == 'p' && dynamic_cast<Pawn *>(grid[enPassantRow][enPassantCol])->isMovedTwo())
            {
                delete grid[enPassantRow][enPassantCol];
                grid[enPassantRow][enPassantCol] = new Empty{pair<int, int>{enPassantRow, enPassantCol}};
            }
        }
        else
        {
            enPassantRow = endPosRow - 1;
            if (grid[enPassantRow][enPassantCol]->getChar() == 'P' && dynamic_cast<Pawn *>(grid[enPassantRow][enPassantCol])->isMovedTwo())
            {
                delete grid[enPassantRow][enPassantCol];
                grid[enPassantRow][enPassantCol] = new Empty{pair<int, int>{enPassantRow, enPassantCol}};
            }
        }
    }
    // make the move for castling
    if ((grid[startPosRow][startPosCol]->getChar() == 'K' || grid[startPosRow][startPosCol]->getChar() == 'k') && abs(startPosCol - endPosCol) == 2)
    {
        int rookStartCol;
        int rookEndCol;

        if (endPosCol > startPosCol)
        {
            rookStartCol = 7;
            rookEndCol = 5;
        }
        else
        {
            rookStartCol = 0;
            rookEndCol = 3;
        }

        delete grid[startPosRow][rookEndCol];
        grid[startPosRow][rookEndCol] = grid[startPosRow][rookStartCol]->clone();
        grid[startPosRow][rookEndCol]->move({startPosRow, rookEndCol});
        dynamic_cast<Rook *>(grid[startPosRow][rookEndCol])->setMoved();
        delete grid[startPosRow][rookStartCol];
        grid[startPosRow][rookStartCol] = new Empty{pair<int, int>{startPosRow, rookStartCol}};
    }

    delete grid[endPosRow][endPosCol];
    grid[endPosRow][endPosCol] = grid[startPosRow][startPosCol]->clone();

    grid[endPosRow][endPosCol]->move(move.end);

    
    if (grid[endPosRow][endPosCol]->getChar() == 'p' || grid[endPosRow][endPosCol]->getChar() == 'P')
    {
        // pawn promotion
        if (endPosRow == 0 || endPosRow == 7)
        {
            

                if (grid[endPosRow][endPosCol]->getChar() == 'p')
                {
                    if (pawnPromote == 'q')
                    {   
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Queen{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        
                    }
                    else if (pawnPromote == 'r')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Rook{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        dynamic_cast<Rook *>(grid[endPosRow][endPosCol])->setMoved();
                        
                    }
                    else if (pawnPromote == 'b')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Bishop{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        
                    }

                    else if (pawnPromote == 'n')
                    {
                        
                        delete grid[endPosRow][endPosCol]; 
                        grid[endPosRow][endPosCol] = new Knight{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                       
                    }
                    else if (pawnPromote == '\0')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Queen{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                    }
                }
                else if (grid[endPosRow][endPosCol]->getChar() == 'P')
                {
                    if (pawnPromote == 'Q')
                    {
                        //cout << "Queenn" << pawnPromote << endl;
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Queen{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        cout << grid[endPosRow][endPosCol]->getChar() << endl;
    
                    }
                    else if (pawnPromote == 'R')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Rook{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        dynamic_cast<Rook *>(grid[endPosRow][endPosCol])->setMoved();

                        
                    }
                    else if (pawnPromote == 'B')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Bishop{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        
                    }

                    else if (pawnPromote == 'N')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Knight{(pair<int, int>{endPosRow, endPosCol}), currentColour};
                        
                    }
                    else if (pawnPromote == '\0')
                    {
                        delete grid[endPosRow][endPosCol];
                        grid[endPosRow][endPosCol] = new Queen{(pair<int, int>{endPosRow, endPosCol}), currentColour};
    
                    }
                }
            }
        
        else {
            dynamic_cast<Pawn *>(grid[endPosRow][endPosCol])->setMoved();
        }

        
        if (abs(endPosRow - startPosRow) == 2)
        {
            // cout << "pawn" << endPosRow << endPosCol << grid[endPosRow][endPosCol]->getColour() << "is moved two active" << endl;
            dynamic_cast<Pawn *>(grid[endPosRow][endPosCol])->setMovedTwo(true);
        }
    }

    else if (grid[endPosRow][endPosCol]->getChar() == 'k' || grid[endPosRow][endPosCol]->getChar() == 'K')
    {
        dynamic_cast<King *>(grid[endPosRow][endPosCol])->setMoved();
    }

    else if (grid[endPosRow][endPosCol]->getChar() == 'r' || grid[endPosRow][endPosCol]->getChar() == 'R')
    {
        dynamic_cast<Rook *>(grid[endPosRow][endPosCol])->setMoved();
    }

    delete grid[startPosRow][startPosCol];

    grid[startPosRow][startPosCol] = new Empty{move.start};
    turnOffMovedTwo(grid[endPosRow][endPosCol]->getColour());
}

Board::~Board()
{

    for (auto row : grid)
    {
        for (auto piece : row)
        {
            if (piece != nullptr)
            {
                delete piece;
            }
        }
    }
}

Board::Board(const Board &other)
{
    grid.resize(other.grid.size());
    for (size_t i = 0; i < other.grid.size(); i++)
    {
        grid[i].resize(other.grid[i].size());
        for (size_t j = 0; j < other.grid.size(); j++)
        {
            grid[i][j] = other.grid[i][j]->clone();
        }
    }
}

Board &Board::operator=(const Board &other)
{
    if (this != &other)
    {
        for (int i = 0; i < GRID_SIZE; i++)
        {
            for (int j = 0; j < GRID_SIZE; j++)
            {
                delete grid[i][j];
            }
        }

        grid.resize(GRID_SIZE, vector<Piece *>(GRID_SIZE, nullptr));

        for (int i = 0; i < GRID_SIZE; ++i)
        {
            for (int j = 0; j < GRID_SIZE; ++j)
            {
                if (other.grid[i][j] != nullptr)
                {
                    grid[i][j] = other.grid[i][j]->clone();
                }
            }
        }
    }
    return *this;
}


vector<Move> Board::getLegalMoves(string col) {
    vector<Move> moves;
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if(grid[i][j]->getColour() != col) continue;
            
            for(auto move: grid[i][j]->getMoves()) {
                if(isLegalMove(move, col, true, false)) {
                    moves.emplace_back(move);
                }
                
            }
        }
    }
    return moves;
}

bool Board::capturesPiece(Move m, string col) {
    if(grid[m.end.first][m.end.second]->getColour() == col) return true;

    return false;
}
