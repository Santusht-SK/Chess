#ifndef __PAWN_H__
#define __PAWN_H__

#include "piece.h"
using namespace std;

class Pawn: public Piece {
    bool moved = false;
    bool movedTwo = false;
    char symbol = 'p';
    public:
        Pawn(pair<int, int> pos, string colour);
        bool isMoved();
        bool isMovedTwo();
        void setMoved();
        void setMovedTwo(bool set);
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        virtual Piece* clone() const override;

        ~Pawn() {}
};


#endif
