#include "computer.h"
#include <random>
#include <cstdlib>
#include <ctime>
#include <climits>
#include <algorithm>
#include <chrono>



int getValue(char p) {
    switch(p) {
        case 'p': return 1; break;
        case 'P': return 1; break;
        case 'b': return 3; break;
        case 'B': return 3; break;
        case 'n': return 3; break;
        case 'N': return 3; break;
        case 'r': return 5; break;
        case 'R': return 5; break;
        case 'q': return 9; break;
        case 'Q': return 9; break;
        case '_': return 0; break;
        case ' ': return 0; break;
    }
    return 0;
}

Computer::Computer(string col, int diff): 
    Player{col}, difficulty{diff} {}

bool Computer::isHuman() {
    return false;
}

Move Computer::getMove(Board &b) {
    if(difficulty == 1) return getMoveOne(b);
    
    if(difficulty == 2) return getMoveTwo(b);
    if(difficulty == 3) return getMoveThree(b);
    if(difficulty == 4) return getMoveFour(b);
    return getMoveOne(b);
}

Move Computer::getMoveOne(Board &b) {
    vector<Move> possible = b.getLegalMoves(getColour());

    int random = rand() % possible.size();
    
    return possible[random];
}

Move Computer::getMoveTwo(Board &b) {
    string col = getColour();
    vector<Move> possible = b.getLegalMoves(col);
    vector<Move> checks;
    vector<Move> captures;
    cout << "two" << endl;

    for(auto move: possible) {
        Board temp = b;
        if(col == "White" && temp.capturesPiece(move, "Black")) {
            captures.emplace_back(move);
        }
        if(col == "Black" && temp.capturesPiece(move, "White")) {
            captures.emplace_back(move);
        }
        temp.makeMove(move, '\0');
        if(col == "White" && temp.isCheckmate("Black")) {
            return move;
        }
        if(col == "Black" && temp.isCheckmate("White")) {
            return move;
        }
        if(col == "White" && temp.isCheck("Black")) {
            checks.emplace_back(move);
        }
        if(col == "Black" && temp.isCheck("White")) {
            checks.emplace_back(move);
        }
    }
    if(captures.size() == 0) {
        if(checks.size() == 0) {
            return getMoveOne(b);
        }
        else{
            int random = rand() % checks.size();
            return checks[random];
        }
    }
    int random = rand() % captures.size();
    return captures[random];
}

Move Computer::getMoveThree(Board &b) {
    string col = getColour();
    vector<Move> possibleW = b.getLegalMoves("White");
    vector<Move> possibleB = b.getLegalMoves("Black");

    vector<Move> checks;
    vector<Move> captures;
    vector<Move> proper;
    
    // loop through possible captures, then checks, then regular moves
    // in hierarchy. Do this for black and white

    if(col == "Black") {
        for(auto move: possibleB) {
            Board temp = b;
            if(temp.capturesPiece(move, "White")) {
                captures.emplace_back(move);
            }
            temp.makeMove(move, '\0');
            if(temp.isCheckmate("White")) {
                return move;
            }
            if(temp.isCheck("White")) {
                checks.emplace_back(move);
            }
        }
       // cout << "looking at captures" << endl;
        for(auto move: captures) {
            
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempW = temp2.getLegalMoves("White");
            vector<Move> attacked;
            for(auto tMove: tempW) {
                if(temp2.capturesPiece(tMove, "Black")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
        //cout << "looking at checks" << endl;
        for(auto move: checks) {
            
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempW = temp2.getLegalMoves("White");
            vector<Move> attacked;
            for(auto tMove: tempW) {
                if(temp2.capturesPiece(tMove, "Black")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
       // cout << "looking at moves" << endl;
        for(auto move: possibleB) {
            
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempW = temp2.getLegalMoves("White");
            vector<Move> attacked;
            for(auto tMove: tempW) {
                if(temp2.capturesPiece(tMove, "Black")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
        cout << "nothing" << endl;
    }
    if(col == "White") {
        for(auto move: possibleW) {
            Board temp = b;
            if(temp.capturesPiece(move, "Black")) {
                captures.emplace_back(move);
            }
            temp.makeMove(move, '\0');
            if(temp.isCheckmate("Black")) {
                return move;
            }
            if(temp.isCheck("Black")) {
                checks.emplace_back(move);
            }
        }
        for(auto move: captures) {
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempB = temp2.getLegalMoves("Black");
            vector<Move> attacked;
            for(auto tMove: tempB) {
                if(temp2.capturesPiece(tMove, "White")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
        for(auto move: checks) {
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempB = temp2.getLegalMoves("Black");
            vector<Move> attacked;
            for(auto tMove: tempB) {
                if(temp2.capturesPiece(tMove, "White")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
        for(auto move: possibleW) {
            Board temp2 = b;
            temp2.makeMove(move, '\0');

            vector<Move> tempB = temp2.getLegalMoves("Black");
            vector<Move> attacked;
            for(auto tMove: tempB) {
                if(temp2.capturesPiece(tMove, "White")) {
                    attacked.emplace_back(tMove);
                }
            }

            if (attacked.size() == 0) {
                proper.emplace_back(move);
            }
        }
        if(proper.size() != 0) {
            int random = rand() % proper.size();
            return proper[random];
        }
    }
    return getMoveTwo(b);
}

string opposite(string col) {
    if(col == "White") return "Black";
    return "White";
}

int evalPos(Board b, string colour) {
    if(b.isCheckmate(opposite(colour))) {
        return 999;
    }
    if(b.isCheckmate(colour)) {
        return -999;
    }
    if(b.isStalemate(colour)) {
        return 0;
    }
    int wSum = 0;
    int bSum = 0;
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if(islower(b.getChar(i, j))) {
                bSum += getValue(b.getChar(i, j));
            }
            else {
                wSum += getValue(b.getChar(i, j));
            }
        }
    }
    if(colour == "Black") {
        return bSum - wSum;
    }
    else return wSum - bSum;
}

int minimaxBlack(Board b, int depth, bool maximizing, int alpha, int beta, string colour) {
    int eval;
    if(depth == 0 || b.isCheckmate("White") || b.isCheckmate("Black") || b.isStalemate(colour)) {
        eval = evalPos(b, "Black");
        return eval;
    }
    vector<Move> moves = b.getLegalMoves(colour);
    if(maximizing) {
        
        int maxi = INT_MIN;
        for(auto move: moves) {
            Board temp = b;
            temp.makeMove(move, '\0');
            eval = minimaxBlack(temp, depth - 1, false, alpha, beta, opposite(colour));
            maxi = std::max(maxi, eval);
            alpha = std::max(alpha, eval);
            if(beta <= alpha) {
                break;
            }
        }
        //cout << "The max is" << maxi << endl;
        return maxi;
    }
    else {
        int mini = INT_MAX;
        for(auto move: moves) {
            Board temp = b;
            temp.makeMove(move, '\0');
            eval = minimaxBlack(temp, depth - 1, true, alpha, beta, opposite(colour));
            mini = std::min(mini, eval);
            beta = std::min(beta, eval);
            if(beta <= alpha) {
                break;
            }
        }
        //cout << "The min is" << mini << endl;
        return mini;
    }
}
int minimaxWhite(Board b, int depth, bool maximizing, int alpha, int beta, string colour) {
    int eval;
    if(depth == 0 || b.isCheckmate("White") || b.isCheckmate("Black") || b.isStalemate(colour)) {
        eval = evalPos(b, "White");
        return eval;
    }
    vector<Move> moves = b.getLegalMoves(colour);
    if(maximizing) {
        
        int maxi = INT_MIN;
        for(auto move: moves) {
            Board temp = b;
            temp.makeMove(move, '\0');
            eval = minimaxWhite(temp, depth - 1, false, alpha, beta, opposite(colour));
            maxi = std::max(maxi, eval);
            alpha = std::max(alpha, eval);
            if(beta <= alpha) {
                break;
            }
        }
        //cout << "The max is" << maxi << endl;
        return maxi;
    }
    else {
        int mini = INT_MAX;
        for(auto move: moves) {
            Board temp = b;
            temp.makeMove(move, '\0');
            eval = minimaxWhite(temp, depth - 1, true, alpha, beta, opposite(colour));
            mini = std::min(mini, eval);
            beta = std::min(beta, eval);
            if(beta <= alpha) {
                break;
            }
        }
        //cout << "The min is" << mini << endl;
        return mini;
    }
}

Move Computer::getMoveFour(Board &b) {
    string col = getColour();
    vector<Move> possible = b.getLegalMoves(col);
    

    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine rng{seed};

    shuffle(possible.begin(), possible.end(), rng);
    
    Move bestmove = Move{pair<int, int>{0,0},{0,0}};
    int highest = -2147483648;
    for(auto move: possible) {
        Board temp = b;
        temp.makeMove(move, '\0');
        int tempo;
        if(col == "Black") {
            tempo = minimaxBlack(temp, 2, false, INT_MIN, INT_MAX, opposite(col));
        }
        else {
            tempo = minimaxWhite(temp, 2, false, INT_MIN, INT_MAX, opposite(col));
        }
        if(tempo > highest) {
            bestmove = move;
            highest = tempo;
        }


    }
    cout << "Current AI prediction: " << highest << endl;
    return bestmove;

}




