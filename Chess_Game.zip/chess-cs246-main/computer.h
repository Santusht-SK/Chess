#ifndef __COMPUTER_H__
#define __COMPUTER_H__

#include "player.h"

class Computer: public Player {
    int difficulty;
    public:
        Computer(string col, int diff);
        virtual Move getMove(Board &b) override;
        virtual bool isHuman() override;
        Move getMoveOne(Board &b);
        Move getMoveTwo(Board &b);
        Move getMoveThree(Board &b);
        Move getMoveFour(Board &b);


};

#endif
