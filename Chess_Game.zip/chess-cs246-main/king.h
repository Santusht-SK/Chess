#ifndef __KING_H__
#define __KING_H__

#include "piece.h"
using namespace std;

class King: public Piece {
    char symbol = 'k';
    bool moved = false;
    public:
        King(pair<int, int> pos, string colour);
        vector<Move> getMoves() override;
        void setMoved();
        virtual char getChar() override;
        virtual bool isMoved();
        virtual Piece* clone() const override;
};



#endif
