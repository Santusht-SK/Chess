#ifndef __QUEEN_H__
#define __QUEEN_H__

#include "piece.h"
using namespace std;

class Queen: public Piece {
    char symbol = 'q';
    public:
        Queen(pair<int, int> pos, string colour);
        virtual vector<Move> getMoves() override;
        virtual char getChar() override;
        virtual Piece* clone() const override;
};


#endif
