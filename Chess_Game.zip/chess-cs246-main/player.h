#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "board.h"


class Player {
    string col;
    public:
        Player(string col);
        string getColour();
        virtual Move getMove(Board &b) = 0;
        virtual bool isHuman() = 0;
        virtual ~Player() = default;
};

#endif
