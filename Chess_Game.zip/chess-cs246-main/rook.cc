#include "rook.h"

using namespace std;

Rook::Rook(pair<int, int> pos, string colour): Piece{pos, colour} {}

vector<Move> Rook::getMoves() {
    vector<Move> moves;
    int row = getPos().first;
    int col = getPos().second;

    // get all moves for moving  left,right,up,down 
    for (int i = 0; i <= 7; i++){
        if (i != row) {
            moves.emplace_back(Move{getPos(),{i, col}});
        }
        
        if (i != col) {
            moves.emplace_back(Move{getPos(),{row, i}});
        }
    }
        

    return moves;
}

char Rook::getChar() {
    if(this->getColour() == "White") {
        return toupper(symbol);
    }
    return symbol;
} 

bool Rook::isMoved() {
    // make the moved change once the rook moves
    return this->moved;
}

Piece* Rook::clone() const {
    return new Rook(*this);
}

void Rook::setMoved() {
    moved = true;
}
