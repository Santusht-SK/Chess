#include "pawn.h"

using namespace std;

Pawn::Pawn(pair<int, int> pos, string colour) : Piece{pos, colour} {}

bool Pawn::isMoved()
{
    // update moved when pawn moves
    return this->moved;
}

bool Pawn::isMovedTwo()
{
    return movedTwo;
}


vector<Move> Pawn::getMoves()
{
    vector<Move> moves;
    int row = getPos().first;
    int col = getPos().second;

    // not done we need to somehow check if the space in it's diagional is empty or has an enemy piece, needs to be done in the baord class
    if (getColour() == "Black")
    {
        if (row < 7)
        {
            moves.emplace_back(Move{getPos(), {row + 1, col}});
        }

        // double move
        if (isMoved() == false && row == 1)
        {
            moves.emplace_back(Move{getPos(), {row + 2, col}});
        }
    }

    // white pawns
    else
    {
        if (row > 0)
        {
            moves.emplace_back(Move{getPos(), {row - 1, col}});
        }
        // double move
        if (isMoved() == false && row == 6)
        {
            moves.emplace_back(Move{getPos(), {row - 2, col}});
        }
    }

    // enPassant + capture
    if (col > 0 && row < 7 && row > 0)
    {
        if (getColour() == "White")
        {

            moves.emplace_back(Move{getPos(), {row - 1, col - 1}});
        }
        else
        {

            moves.emplace_back(Move{getPos(), {row + 1, col - 1}});
        }
    }

    if (col < 7 && row < 7 && row > 0)
    {
        if (getColour() == "White")
        {
            moves.emplace_back(Move{getPos(), {row - 1, col + 1}});
        }
        else
        {
            moves.emplace_back(Move{getPos(), {row + 1, col + 1}});
        }
    }
    return moves;
}


char Pawn::getChar()
{
    if (this->getColour() == "White")
    {
        return toupper(symbol);
    }
    return symbol;
}

void Pawn::setMoved()
{
    moved = true;
}

void Pawn::setMovedTwo(bool set)
{
    if (set)
    {
        movedTwo = true;
    }
    else
    {
        movedTwo = false;
    }
}

Piece *Pawn::clone() const
{
    return new Pawn(*this);
}
