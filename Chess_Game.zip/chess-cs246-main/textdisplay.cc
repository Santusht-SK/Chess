#include "textdisplay.h"

TextDisplay::TextDisplay() {
    theDisplay.resize(8);
    for(int i = 0; i < 8; i++) {
        theDisplay[i].resize(8);
        for(int j = 0; j < 8; j++) {
            if(i + j % 2 == 0) {
                theDisplay[i][j] = ' ';
            }
            theDisplay[i][j] = '_';
        }
    }
}

void TextDisplay::notify(Board &b) {
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            theDisplay[i][j] = b.getChar(i, j);
        }
    }
}

std::ostream &operator<<(std::ostream &out, const TextDisplay &td) {
    int row = 8;
    for(int i = 0; i < 8; i++) {
        out << row << ' ';
        for(int j = 0; j < 8; j++) {
            out << td.theDisplay[i][j];
        }
        out << '\n';
        row -=1;
    }
    out << "\n  abcdefgh\n";
    return out;
}

TextDisplay::~TextDisplay() {}
