#include "player.h"

Player::Player(string col): col{col} {}

string Player::getColour() {
    return col;
}
