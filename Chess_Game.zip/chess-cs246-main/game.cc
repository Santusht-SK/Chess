#include "game.h"
#include <iostream>

Game::Game() : b(Board{}), td(new TextDisplay{}), gd(new GraphicsDisplay{}), turn{"White"}
{
    gd->notify(b);
}

void Game::remove(pair<int, int> pos)
{
    b.setPos('e', pos);
}

void Game::addPiece(pair<int, int> pos, Piece &p)
{
    b.setPos(p.getChar(), pos);
}

void Game::setTurn(string col)
{
    turn = col;
}

void Game::clearBoard()
{
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            b.setPos('e', pii{i, j});
        }
    }
}

void Game::printResults()
{
    updateBoard();
    cout << *td;
}

void Game::updateBoard()
{
    td->notify(b);
    gd->notify(b);
}

bool Game::makeMove(pair<int, int> p1, pair<int, int> p2, string colour)
{
    if (b.isLegalMove(Move{p1, p2}, colour, true, (pWhite->isHuman() || pBlack->isHuman())))
    {
        char pieceChar = b.getChar(p1.first, p1.second);
        if ((pieceChar == 'p' || pieceChar == 'P') && (p2.first == 0 || p2.first == 7) && ((colour == "White" && pWhite->isHuman()) || (colour == "Black" && pBlack->isHuman())))
        {
            char pawnPromote;
            while (!cin.eof())
            {
                cin >> pawnPromote;
                if ((pieceChar == 'p' && (pawnPromote == 'q' || pawnPromote == 'r' || pawnPromote == 'n' || pawnPromote == 'b')) ||
                    (pieceChar == 'P' && (pawnPromote == 'Q' || pawnPromote == 'R' || pawnPromote == 'N' || pawnPromote == 'B')))
                {
                    b.makeMove((Move{p1, p2}), pawnPromote);
                    return true;
                }

                else
                {
                    cout << "Invalid Promote, try again! (Caps Sensitive)" << endl;
                }
            }
        }
        else
        {
            b.makeMove((Move{p1, p2}), '\0');
            return true;
        }
    }
    return false;
}

pii convertPos(string pos)
{
    int r = pos[0] - 97;
    return pii{8 - (pos[1] - '0'), r};
}

void Game::runGame()
{
    string cmd;
    while (!cin.eof())
    {
        cin >> cmd;
        if (cmd == "setup")
        {
            cout << "entering setup mode" << endl;
            clearBoard();
            printResults();
            string cmd2;

            while (!cin.eof())
            {
                cin >> cmd2;
                if (cmd2 == "done")
                {
                    if (b.isValid())
                    {
                        cout << "Exiting setup mode." << endl;
                        break;
                    }
                    else
                        cout << "The board is invalid." << endl;
                    printResults();
                }
                else if (cmd2 == "+")
                {
                    char piece;
                    string pos;
                    cin >> piece >> pos;
                    b.setPos(piece, convertPos(pos));
                    printResults();
                }
                else if (cmd2 == "-")
                {
                    string pos;
                    cin >> pos;
                    this->remove(convertPos(pos));
                    printResults();
                }
                else if (cmd2 == "=")
                {
                    string col;
                    while (!cin.eof())
                    {
                        cin >> col;
                        if (col.length() != 5)
                        {
                            cout << "Invalid colour. 1" << col.length() << endl;
                            continue;
                        }
                        col[0] = toupper(col[0]);
                        for (int i = 1; i < 5; i++)
                        {
                            col[i] = tolower(col[i]);
                        }
                        cout << col << endl;
                        if (col != "White" && col != "Black")
                        {
                            cout << "Invalid colour." << endl;
                            continue;
                        }
                        break;
                    }
                    this->setTurn(col);
                    cout << "It is now " << turn << " to move." << endl;
                }
                else
                {
                    cout << "Invalid command." << endl;
                }
            }
        }
        else if (cmd == "game")
        {
            string tempWhite;
            string tempBlack;

            while (!cin.eof())
            {
                cin >> tempWhite >> tempBlack;
                if (tempWhite == "human")
                    pWhite = std::make_unique<Human>("White");

                else
                {
                    if (tempWhite == "computer[1]")
                        pWhite = std::make_unique<Computer>("White", 1);
                    else if (tempWhite == "computer[2]")
                        pWhite = std::make_unique<Computer>("White", 2);
                    else if (tempWhite == "computer[3]")
                        pWhite = std::make_unique<Computer>("White", 3);
                    else if (tempWhite == "computer[4]")
                        pWhite = std::make_unique<Computer>("White", 4);
                    else
                    {
                        cout << "Invalid player." << endl;
                        continue;
                    }
                }
                if (tempBlack == "human")
                    pBlack = std::make_unique<Human>("Black");
                else
                {
                    if (tempBlack == "computer[1]")
                        pBlack = std::make_unique<Computer>("Black", 1);
                    else if (tempBlack == "computer[2]")
                        pBlack = std::make_unique<Computer>("Black", 2);
                    else if (tempBlack == "computer[3]")
                        pBlack = std::make_unique<Computer>("Black", 3);
                    else if (tempBlack == "computer[4]")
                        pBlack = std::make_unique<Computer>("Black", 4);
                    else
                    {
                        cout << "Invalid player." << endl;
                        continue;
                    }
                }
                break;
            }

            while (!cin.eof())
            {
                Move temp = {pii{0, 0}, pii{0, 0}};
                string cmd3;
                printResults();

                cout << turn << " to move." << endl;
                if (turn == "White" && pWhite->isHuman() == false)
                {
                    cout << "Would you like the computer to move or resign?" << endl;
                }
                else if (turn == "Black" && pBlack->isHuman() == false)
                {
                    cout << "Would you like the computer to move or resign?" << endl;
                }
                else
                    cout << "Would you like to move or resign?" << endl;

                cin >> cmd3;
                if (cmd3 == "resign")
                {
                    if (turn == "White")
                    {
                        cout << "Black wins!" << endl;
                        blackScore += 1;
                    }
                    else
                    {
                        cout << "White wins!" << endl;
                        whiteScore += 1;
                    }
                    break;
                }
                if (cmd3 != "move")
                {
                    cout << "Invalid command." << endl;
                    continue;
                }

                while (!cin.eof())
                {
                    if (turn == "White")
                        temp = pWhite->getMove(b);
                    if (turn == "Black")
                        temp = pBlack->getMove(b);

                    if (!makeMove(temp.start, temp.end, turn))
                    {
                        cout << "Invalid Move" << endl << endl;
                    }
                    else
                        break;
                }

                if (turn == "White" && b.isStalemate("Black"))
                {
                    cout << "Stalemate!" << endl;
                    blackScore += 0.5;
                    whiteScore += 0.5;
                    break;
                }

                if (turn == "Black" && b.isStalemate("White"))
                {
                    cout << "Stalemate!" << endl;
                    blackScore += 0.5;
                    whiteScore += 0.5;
                    break;
                }

                if (b.isCheckmate("Black"))
                {
                    cout << "Checkmate! White wins!" << endl;
                    whiteScore += 1;
                    break;
                }

                if (b.isCheckmate("White"))
                {
                    cout << "Checkmate! Black wins!" << endl;
                    blackScore += 1;
                    break;
                }

                
                if(b.isCheck("White")) {
                    cout << "White is in check." << endl;
                }
                if(b.isCheck("Black")) {
                    cout << "Black is in check." << endl;
                } 

                if (turn == "White")
                {
                    turn = "Black";
                }
                else
                    turn = "White";
            }
            printResults();
            b = Board{};
        }

        /*

       // everything in these comments was to test different sequence of moves and legality issues
        if(makeMove(pii{1,2},pii{2,2}, "Black")) printResults();
        if(makeMove(pii{0,1},pii{2,2}, "Black")) printResults();
        if(makeMove(pii{2,2},pii{4,1}, "Black")) printResults();
        // bishop move (shouldnt work paawn in the way)
         if(makeMove(pii{0,2},pii{2,0}, "Black")) printResults();
         // pawn double
        if(makeMove(pii{1,1},pii{3,1}, "Black")) printResults();
        //bishop move
        if(makeMove(pii{0,2},pii{1,1}, "Black")) printResults();
        // chekc if knight cpattures a pawn (IT DOES)
        if(makeMove(pii{4,1},pii{6,2}, "Black")) printResults();
        // move knight back to where it wsa b4
        if(makeMove(pii{6,2},pii{4,1}, "Black")) printResults();
        // cpature another piece to see if grid updates properly
        if(makeMove(pii{4,1},pii{6,2}, "Black")) printResults();
        // knight cpatures their knight
        if(makeMove(pii{6,2},pii{7,0}, "Black")) printResults();
        // grid updates with a _ as it should WWW
        if(makeMove(pii{7,0},pii{6,2}, "Black")) printResults();
        // can their captured knight move or is it gone? ITS GONE!
        if(makeMove(pii{7,0},pii{6,2}, "White")) printResults();
        // pawn moves when king is in check, need to fix
        if(makeMove(pii{6,3},pii{5,3}, "White")) printResults();
        // can queen capture the enemy knight that puts the white king in check? It Works
        if(makeMove(pii{7,3},pii{6,2}, "White")) printResults();
         */

        // next sequence of moves is to check for checkmate (fool's mate) IT WORKSSS

        /*
        if(makeMove(pii{6,5},pii{5,5}, "White")) printResults();
        if(makeMove(pii{1,4},pii{3,4}, "Black")) printResults();
        if(makeMove(pii{6,6},pii{4,6}, "White")) printResults();
        if(makeMove(pii{0,3},pii{4,7}, "Black")) printResults();
        if(b.isCheckmate("White")) {
            cout << "White is mated" << endl;
        }
        */

        /*
        // these sequence of moves cheks for stalemate and it works
         if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();

         if(makeMove(convertPos("a7"),convertPos("a5"), "Black")) printResults();
         if(makeMove(convertPos("d1"),convertPos("h5"), "White")) printResults();
         if(makeMove(convertPos("a8"),convertPos("a6"), "Black")) printResults();
         if(makeMove(convertPos("h5"),convertPos("a5"), "White")) printResults();
         if(makeMove(convertPos("h7"),convertPos("h5"), "Black")) printResults();
         if(makeMove(convertPos("a5"),convertPos("c7"), "White")) printResults();

         if(makeMove(convertPos("a6"),convertPos("h6"), "Black")) printResults();

         if(makeMove(convertPos("h2"),convertPos("h4"), "White")) printResults();
         if(makeMove(convertPos("f7"),convertPos("f6"), "Black")) printResults();
         if(makeMove(convertPos("c7"),convertPos("d7"), "White")) printResults();
         if(makeMove(convertPos("e8"),convertPos("f7"), "Black")) printResults();
         if(makeMove(convertPos("d7"),convertPos("b7"), "White")) printResults();
         if(makeMove(convertPos("d8"),convertPos("d3"), "Black")) printResults();
         if(makeMove(convertPos("b7"),convertPos("b8"), "White")) printResults();
         if(makeMove(convertPos("d3"),convertPos("h7"), "Black")) printResults();
         if(makeMove(convertPos("b8"),convertPos("c8"), "White")) printResults();
         if(makeMove(convertPos("f7"),convertPos("g6"), "Black")) printResults();
         if(makeMove(convertPos("c8"),convertPos("e6"), "White")) printResults();
         if (b.isCheckmate("Black")) {
            cout << "Black is mated" << endl;
         }
        if (b.isStalemate("Black")) {
            cout << "Black is stalemated" << endl;
         }
*/

        /*

        // lets check if castling works right side
            if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("d3"), "White")) printResults();
            if(makeMove(convertPos("g1"),convertPos("h3"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("g1"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("e1"), "White")) printResults();
        */

        /*
        // castling while in check?
            if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("d3"), "White")) printResults();
            if(makeMove(convertPos("g1"),convertPos("h3"), "White")) printResults();
            if(makeMove(convertPos("e7"),convertPos("e6"), "Black")) printResults();
            if(makeMove(convertPos("d8"),convertPos("g5"), "Black")) printResults();
            if(makeMove(convertPos("g5"),convertPos("e3"), "Black")) printResults();
            if(makeMove(convertPos("e1"),convertPos("g1"), "White")) printResults();
            */

        /*
        // lets check if castling works if piece in the way right side
            if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("d3"), "White")) printResults();
            //if(makeMove(convertPos("g1"),convertPos("h3"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("g1"), "White")) printResults();

            */

        /*
        // lets check if castling works if king has moved
            if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("d3"), "White")) printResults();
            if(makeMove(convertPos("g1"),convertPos("h3"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("e2"), "White")) printResults();
            if(makeMove(convertPos("e2"),convertPos("e1"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("g1"), "White")) printResults();
        */

        /*

        // lets check if castling works if rook has moved
            if(makeMove(convertPos("e2"),convertPos("e3"), "White")) printResults();
            if(makeMove(convertPos("f1"),convertPos("d3"), "White")) printResults();
            if(makeMove(convertPos("g1"),convertPos("h3"), "White")) printResults();
            if(makeMove(convertPos("h1"),convertPos("g1"), "White")) printResults();
            if(makeMove(convertPos("g1"),convertPos("h1"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("g1"), "White")) printResults();

            */
        /*

           // lets check if castling works left side
            if(makeMove(convertPos("d2"),convertPos("d3"), "White")) printResults();
            if(makeMove(convertPos("c1"),convertPos("e3"), "White")) printResults();
             if(makeMove(convertPos("d1"),convertPos("d2"), "White")) printResults();
            if(makeMove(convertPos("b1"),convertPos("c3"), "White")) printResults();
            if(makeMove(convertPos("e1"),convertPos("c1"), "White")) printResults();

            */
        /*

           // let's check the black side for castling left side
            if(makeMove(convertPos("e7"),convertPos("e5"), "Black")) printResults();
            if(makeMove(convertPos("f8"),convertPos("d6"), "Black")) printResults();
            if(makeMove(convertPos("d8"),convertPos("e7"), "Black")) printResults();
            if(makeMove(convertPos("g8"),convertPos("h6"), "Black")) printResults();
            if(makeMove(convertPos("e8"),convertPos("g8"), "Black")) printResults();


        */

        /*

           // let's check the black side for castling right side
            if(makeMove(convertPos("d7"),convertPos("d6"), "Black")) printResults();
            if(makeMove(convertPos("c8"),convertPos("e6"), "Black")) printResults();
            if(makeMove(convertPos("d8"),convertPos("d7"), "Black")) printResults();
            if(makeMove(convertPos("b8"),convertPos("c6"), "Black")) printResults();
            if(makeMove(convertPos("e8"),convertPos("c8"), "Black")) printResults();
            */

        /*

        // pawn captures work
           if(makeMove(convertPos("e2"),convertPos("e4"), "White")) printResults();
           if(makeMove(convertPos("f7"),convertPos("f5"), "Black")) printResults();
           if(makeMove(convertPos("f5"),convertPos("e4"), "Black")) printResults();
           */
        /*

      // can't enPassant since a move has passed (missed their chance)
        if(makeMove(convertPos("f7"),convertPos("f5"), "Black")) printResults();
        if(makeMove(convertPos("f5"),convertPos("f4"), "Black")) printResults();
        if(makeMove(convertPos("e2"),convertPos("e4"), "White")) printResults();
        if(makeMove(convertPos("b8"),convertPos("c6"), "Black")) printResults();
        if(makeMove(convertPos("f4"),convertPos("e3"), "Black")) printResults();
        // see if capturing normally with another paawn still works
        if(makeMove(convertPos("d7"),convertPos("d5"), "Black")) printResults();
        if(makeMove(convertPos("d5"),convertPos("e4"), "Black")) printResults();
        */
        /*

        // can enPassant
          if(makeMove(convertPos("f7"),convertPos("f5"), "Black")) printResults();
          if(makeMove(convertPos("f5"),convertPos("f4"), "Black")) printResults();
          if(makeMove(convertPos("e2"),convertPos("e4"), "White")) printResults();
          if(makeMove(convertPos("f4"),convertPos("e3"), "Black")) printResults();
          */
        /*
       // white enpassants black on the edge of the board
        if(makeMove(convertPos("g2"),convertPos("g4"), "White")) printResults();
        if(makeMove(convertPos("g4"),convertPos("g5"), "White")) printResults();
        if(makeMove(convertPos("h7"),convertPos("h5"), "Black")) printResults();
        if(makeMove(convertPos("g5"),convertPos("h6"), "White")) printResults();
        // move knight to whre paawn died to make sure empty space was properly made

        if(makeMove(convertPos("g8"),convertPos("f6"), "Black")) printResults();
        if(makeMove(convertPos("f6"),convertPos("h5"), "Black")) printResults();
       */

        // tetsing out diff move patterns and checking logic (print statements are shwoing that
        //  different moves arent allowed since we are in check)

        /*

        if(makeMove(convertPos("d2"),convertPos("d4"), "White")) printResults();
        if(makeMove(convertPos("e2"),convertPos("e4"), "White")) printResults();
                 if (b.isCheckmate("Black")) {
                    cout << "Black is mated" << endl;
                 }
                if (b.isStalemate("Black")) {
                    cout << "Black is stalemated" << endl;
                 }
        if(makeMove(convertPos("f7"),convertPos("f5"), "Black")) printResults();
                 if (b.isCheckmate("Black")) {
                    cout << "Black is mated" << endl;
                 }
                if (b.isStalemate("Black")) {
                    cout << "Black is stalemated" << endl;
                 }
        if(makeMove(convertPos("g7"),convertPos("g5"), "Black")) printResults();
                 if (b.isCheckmate("Black")) {
                    cout << "Black is mated" << endl;
                 }
                if (b.isStalemate("Black")) {
                    cout << "Black is stalemated" << endl;
                 }

        if(makeMove(convertPos("d1"),convertPos("h5"), "White")) printResults();


                 if (b.isCheckmate("Black")) {
                    cout << "Black is mated" << endl;
                 }

        */

        /*

if(makeMove(convertPos("g7"),convertPos("g5"), "Black")) printResults();

if(makeMove(convertPos("d2"),convertPos("d4"), "White")) printResults();
if(makeMove(convertPos("e2"),convertPos("e4"), "White")) printResults();
         if (b.isCheckmate("Black")) {
            cout << "Black is mated" << endl;
         }
        if (b.isStalemate("Black")) {
            cout << "Black is stalemated" << endl;
         }
if(makeMove(convertPos("f7"),convertPos("f5"), "Black")) printResults();
         if (b.isCheckmate("Black")) {
            cout << "Black is mated" << endl;
         }
        if (b.isStalemate("Black")) {
            cout << "Black is stalemated" << endl;
         }
if(makeMove(convertPos("d1"),convertPos("h5"), "White")) printResults();
         if (b.isCheckmate("Black")) {
            cout << "Black is mated" << endl;
         }
          if (b.isStalemate("Black")) {
            cout << "Black is stalemated" << endl;
         }
         */
    }
    cout << "Final Score:" << endl;
    cout << "White: " << whiteScore << endl;
    cout << "Black: " << blackScore << endl;
}

Game::~Game()
{
    delete td;
    delete gd;
}
