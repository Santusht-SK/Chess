#include "empty.h"

using namespace std;

Empty::Empty(pair<int, int> pos): Piece{pos, "null"} {}

char Empty::getChar() {
    if ((getPos().first + getPos().second) % 2 == 0) {
        return ' ';
    }
    return symbol;
}

vector<Move> Empty::getMoves(){
    vector<Move> v;
    return v;
}

Piece* Empty::clone() const {
    return new Empty(*this);
}

