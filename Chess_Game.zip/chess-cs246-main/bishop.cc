#include "bishop.h"
#include <vector>

using namespace std;

Bishop::Bishop(pair<int, int> pos, string colour): Piece{pos, colour} {}

vector<Move> Bishop::getMoves() {
    vector<Move> moves;
    pair<int, int> start = getPos();
    int row = getPos().first;
    int col = getPos().second;

    // get all moves for moving south-east
    for (int i = 1; i + row < 8 && col + i < 8; i++){
        moves.emplace_back(Move{start, row + i, col + i});
    }

    // get all moves for moving south-west
    for (int i = 1; i + row < 8 && col - i >= 0; i++){
        moves.emplace_back(Move{start, row + i, col - i});
    }

    // get all moves for moving north-east
    for (int i = 1; row - i >=0 && col + i < 8; i++){
        moves.emplace_back(Move{start, row - i, col + i});
    }

    // north west
    for (int i = 1; row - i >= 0 && col - i >= 0; i++){
        moves.emplace_back(Move{start, row - i, col - i});
    }
    return moves;
}


char Bishop::getChar() {
    if(this->getColour() == "White") {
        return toupper(symbol);
    }
    return symbol;
} 

Piece* Bishop::clone() const {
    return new Bishop(*this);
}



