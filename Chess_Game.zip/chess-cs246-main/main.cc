#include "game.h"
#include "board.h"
#include <string>
#include <iostream>



using namespace std;

int main() {
    srand(time(0));

    Game g = Game{};

    g.runGame();


}


